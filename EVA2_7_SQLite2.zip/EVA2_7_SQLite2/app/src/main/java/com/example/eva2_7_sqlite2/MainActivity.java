package com.example.eva2_7_sqlite2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase database;
    EditText name, cell;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.edName);
        cell = findViewById(R.id.edCell);

        database = this.openOrCreateDatabase("myDB",MODE_PRIVATE,null);
    }
    public void capturar(View view){
        if(name.getText().toString().equals("") && cell.getText().toString().equals("")){
            Toast.makeText(this,"Complete los campos", Toast.LENGTH_SHORT).show();
        } else {
            String names = name.getText().toString();
            String cellphone = cell.getText().toString();

            database.beginTransaction();

            try {
                database.setTransactionSuccessful();

                database.execSQL("create table if not exists tblUser (" +
                        "id integer PRIMARY KEY autoincrement, " +
                        "name text, " +
                        "phone text);");

                database.execSQL("insert into tblUser(name, phone) values ('"+names+"','"+cellphone+"');");
                name.setText("");
                cell.setText("");
                Toast.makeText(this,"Se agrego correctamente", Toast.LENGTH_SHORT).show();

            } catch (SQLException e){
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            } finally {
                database.endTransaction();
            }

        }
    }

    public void consultar(View view){
        database.beginTransaction();

        try {
            database.setTransactionSuccessful();

            database.execSQL("create table if not exists tblUser (" +
                    "id integer PRIMARY KEY autoincrement, " +
                    "name text, " +
                    "phone text);");

            String consultaSQL = "select * from tblUser";
            Cursor cursor = database.rawQuery(consultaSQL, null);
            String list = "id   Nombre  Celular\n";

            while (cursor.moveToNext()){
                list+=cursor.getInt(0)+"    "+cursor.getString(1)+"     "+cursor.getString(2)+"\n";
            }

            Intent intent = new Intent(this,ListActivity.class);
            intent.putExtra("lista", list);
            startActivity(intent);

        } catch (SQLException e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            database.endTransaction();
        }
    }

}
