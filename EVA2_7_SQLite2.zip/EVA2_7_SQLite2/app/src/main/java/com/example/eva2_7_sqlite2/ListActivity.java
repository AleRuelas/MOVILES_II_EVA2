package com.example.eva2_7_sqlite2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ListActivity extends AppCompatActivity {

    String showList;
    TextView txtList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        txtList = findViewById(R.id.txtList);

        Intent intent = getIntent();
        txtList.setText(intent.getStringExtra("lista"));

    }

    public void setShowList(String showList){
        this.showList = showList;
    }
}
