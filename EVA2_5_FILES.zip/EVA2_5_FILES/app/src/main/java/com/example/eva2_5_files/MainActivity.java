package com.example.eva2_5_files;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
//Pedir permiso
public class MainActivity extends AppCompatActivity {
    EditText edTxt;
    final String ARCHIVO = "mi_archivo.txt";
    final int PERMISO_ESCRITURA=1;
    String sRutaSD;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //AQUI HABRIA QUE TOMAR DESICIONES SOBRE LOS PERMISOS, PARA GRABAR EN LA MEMORIA DEL DISPOSITIVO

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edTxt = findViewById(R.id.edTxt);
        //Tarjeta de memoria
        //sRutaSD = Environment.getExternalStorageDirectory().getAbsolutePath();

        //Para version 10
        sRutaSD = getExternalFilesDir(Environment.DIRECTORY_MUSIC).getPath();
        Toast.makeText(this, sRutaSD,Toast.LENGTH_LONG).show();

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
                     ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            PERMISO_ESCRITURA);

        }

    }

    public void onRead(View view){
        try {
            //DE LA 5 PARA ABAJO
            //InputStream is = openFileInput(ARCHIVO);

            //INDICAR LA RUTA A GUARDAR Y EL ARCHIVO A GUARDAR. DE LA 6 A LA 9
            //FileInputStream is = new FileInputStream(sRutaSD + "/"+ ARCHIVO);

            //FUNCION PARA ACCEDER A CARPETA EN ESPECIAL. DE LA 10 PARA ARRIBA
            File file = new File(getExternalFilesDir(null), ARCHIVO);
            FileInputStream is = new FileInputStream(file);

            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String sCade;
            try {
                while ((sCade = br.readLine()) != null) {
                    edTxt.append(sCade);
                    edTxt.append("\n");
                }
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public void onWrite(View view){
        String sCade = edTxt.getText().toString();
        try {
            //DE LA 5 PARA ABAJO
            //OutputStream os = openFileOutput(ARCHIVO, MODE_PRIVATE);

            //DE LA 6 A LA 9
            //FileOutputStream os = new FileOutputStream(sRutaSD + "/" + ARCHIVO);

            //PARA 10 Y ARRIBA
            File file = new File(getExternalFilesDir(null), ARCHIVO);
            FileOutputStream os = new FileOutputStream(file);

            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);
            bw.write(sCade);
            bw.close();
        }catch (Exception e){
            e.printStackTrace();
        }


    }


}
