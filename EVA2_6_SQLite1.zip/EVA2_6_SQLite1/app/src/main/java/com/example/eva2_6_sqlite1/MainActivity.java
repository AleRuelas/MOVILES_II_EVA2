package com.example.eva2_6_sqlite1;

import androidx.appcompat.app.AppCompatActivity;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity {

SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView txtMsg = findViewById(R.id.txtMsg);

        database = this.openOrCreateDatabase("myDB",MODE_PRIVATE,null);
        database.beginTransaction();
        try {

            database.setTransactionSuccessful();

            database.execSQL("create table tblUser (" +
                    "id integer PRIMARY KEY autoincrement, " +
                    "name text, " +
                    "phone text);");


            database.execSQL("insert into tblUser(name, phone) values ('ALE','614-217-0537');");
            database.execSQL("insert into tblUser(name, phone) values ('LEA','614-217-0537');");
            database.execSQL("insert into tblUser(name, phone) values ('EAL','614-217-0537');");

            txtMsg.append("\nAll done!");
        } catch (SQLException e){
            txtMsg.append("\nError "+e.getMessage());

        } finally {
            database.endTransaction();
        }

    }


}
